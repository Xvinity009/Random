Password - ryos

How to Use?

Open Zip and Folder
Launch Bootstrapper.exe
Enjoy the game.

by Nah, I'd Exploiting XD